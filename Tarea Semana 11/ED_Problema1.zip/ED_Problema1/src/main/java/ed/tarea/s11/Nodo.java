package ed.tarea.s11;

public class Nodo {
    int valor;
    Nodo nodoDerecho;
    Nodo nodoIzquierdo;

    Nodo(int valor) {
        this.valor = valor;
    }


}

